export default async (request) => {
  const headers = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
  };

  if (request.method === "OPTIONS") return new Response("", { status: 204, headers });
  if (request.method !== "POST") {
    return new Response(JSON.stringify({ error: "Only POST is supported." }), { status: 405, headers });
  }

  try {
    const apiKey = Netlify.env.get("GEMINI_API_KEY");
    if (!apiKey) {
      return new Response(JSON.stringify({ error: "Netlify par GEMINI_API_KEY set nahi hai." }), { status: 503, headers });
    }

    const body = await request.json();
    const imageDataUrl = body.imageDataUrl || "";
    const match = imageDataUrl.match(/^data:(image\/(?:png|jpeg|jpg|webp));base64,([A-Za-z0-9+/=]+)$/);
    if (!match) {
      return new Response(JSON.stringify({ error: "Valid JPG, PNG ya WEBP photo bhejein." }), { status: 400, headers });
    }
    if (imageDataUrl.length > 16_000_000) {
      return new Response(JSON.stringify({ error: "Photo bahut badi hai. 12 MB se chhoti photo use karein." }), { status: 413, headers });
    }

    const mimeType = match[1] === "image/jpg" ? "image/jpeg" : match[1];
    const imageBase64 = match[2];
    const ledgerList = Array.isArray(body.ledgers)
      ? body.ledgers.slice(0, 250).map(x => `${String(x.name || "").slice(0,80)} (${String(x.group || "").slice(0,80)})`).join(", ")
      : "";

    const prompt = `You are the visual accounting assistant inside HONEY TALLY, an Indian double-entry bookkeeping app.
Understand the attached image like a careful human assistant, not merely OCR. It may be a printed bill, receipt, handwritten notebook, bank/payment screenshot, voucher, statement, or photo containing transaction details.
Company: ${String(body.companyName || "Current company").slice(0,120)}
Existing ledgers (use exact names when clearly suitable): ${ledgerList || "No ledger list supplied"}.

Instructions:
1. Understand the complete visual context and identify what transaction actually happened.
2. Extract only visible facts: date, party, item/description, amount, tax, payment mode, and other details where readable.
3. Convert each clearly supported transaction into a simple accounting sentence for Smart Entry, such as:
   "Paid rent 5000 by cash"
   "Goods sold to Rahul 12000 on credit"
   "Purchased furniture 20000 by bank"
   "Received 5000 from Amit in cash"
4. If one image contains multiple separate transactions, put each on a separate line.
5. Never invent missing names, dates, amounts, tax rates, payment modes, or transactions. If unclear, state UNCLEAR rather than guessing.
6. If it is not an accounting image or no transaction is visible, say so.
7. Do not calculate or assume balancing entries. Do not claim anything was saved.
8. Return ONLY this exact structure:
ENTRY LINES:
<one transaction per line>
NOTES:
<short uncertainties or None>
Use Hindi or English accounting words that are easy for the user to review.`;

    const apiResponse = await fetch(
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent",
      {
        method: "POST",
        headers: {
          "x-goog-api-key": apiKey,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          contents: [{
            role: "user",
            parts: [
              { text: prompt },
              { inline_data: { mime_type: mimeType, data: imageBase64 } }
            ]
          }],
          generationConfig: {
            temperature: 0.1,
            maxOutputTokens: 1200
          }
        })
      }
    );

    const result = await apiResponse.json().catch(() => ({}));
    if (!apiResponse.ok) {
      const message = result?.error?.message || "Gemini Vision request failed.";
      return new Response(JSON.stringify({ error: message }), { status: apiResponse.status, headers });
    }

    const outputText = (result.candidates || [])
      .flatMap(candidate => candidate.content?.parts || [])
      .map(part => part.text || "")
      .join("\n")
      .trim();

    if (!outputText) {
      return new Response(JSON.stringify({ error: "Gemini ne readable response nahi diya. Clear photo lekar try karein." }), { status: 502, headers });
    }

    const matchEntries = outputText.match(/ENTRY LINES:\s*([\s\S]*?)(?:\nNOTES:|$)/i);
    const entryText = (matchEntries ? matchEntries[1] : outputText)
      .split(/\r?\n/)
      .map(line => line.replace(/^\s*(?:[-*•]|\d+[.)])\s*/, "").trim())
      .filter(Boolean)
      .join("\n");

    const notesMatch = outputText.match(/NOTES:\s*([\s\S]*)$/i);
    return new Response(JSON.stringify({
      entryText,
      notes: notesMatch ? notesMatch[1].trim() : ""
    }), { status: 200, headers });
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message || "Unexpected server error." }), { status: 500, headers });
  }
};
